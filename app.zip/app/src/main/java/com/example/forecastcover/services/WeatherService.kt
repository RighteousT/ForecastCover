package com.example.forecastcover.services

// Placeholder service interface for future API calls
interface WeatherService {
    fun getCurrentWeather(): String
    fun getForecast(): String
}
